<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <link rel="stylesheet" href="<?=base_url();?>/assets/style.css">
</head>
<body>
    <div class="container">
    <header>
        <h1>PROJECT LAB 12</h1>
    </header>
    <?php include_once('topnav.php'); ?>
    <div class="wrapper">
