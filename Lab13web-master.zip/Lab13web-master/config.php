<?php

$config['base_url'] = '/LAB12_PHP_LOGIN';
$config['rewrite']  = false;

// database config
$config['db_host'] = 'localhost';
$config['db_name'] = 'lat1';
$config['db_username'] ='root';
$config['db_password'] ='';
